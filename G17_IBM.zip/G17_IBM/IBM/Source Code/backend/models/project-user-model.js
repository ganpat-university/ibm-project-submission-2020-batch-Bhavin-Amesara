const mongoose = require('mongoose');

// project_user
// id            INT(11)       PRIMARY KEY       AUTO_INCREMENT
// project_id    INT(11)       FOREIGN KEY       REFERENCES project(id)
// user_id       INT(11)       FOREIGN KEY       REFERENCES user(id)
// assigned_by   INT(11)       FOREIGN KEY       REFERENCES user(id)
// is_deleted    BOOLEAN       DEFAULT FALSE
// created_at    TIMESTAMP     DEFAULT CURRENT_TIMESTAMP
// updated_at    TIMESTAMP     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP

const ProjectUserSchema = new mongoose.Schema({
    projectId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Project',
        required: true
    },
    userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    assignedBy: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    isDeleted: {
        type: Boolean,
        default: false,
    },
});

module.exports = mongoose.model('ProjectUser', ProjectUserSchema);