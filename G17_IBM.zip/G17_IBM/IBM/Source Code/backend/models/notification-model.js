const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// Notification Schema
// notification_title VARCHAR(255) NOT NULL
// notification_description TEXT NOT NULL
// notification_date DATE NOT NULL
// notification_status ENUM('unread', 'read') NOT NULL
// notification_type ENUM('assigned', 'commented', 'status changed', 'priority changed', 'deleted', 'create') NOT NULL
// notification_from VARCHAR(255) NOT NULL
// notification_to VARCHAR(255) NOT NULL
// isDeleted BOOLEAN DEFAULT FALSE
// created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
// updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP

let Notification = new Schema({
    notification_title: {
        type: String,
        required: true
    },
    notification_description: {
        type: String,
        required: true
    },
    notification_date: {
        type: Date,
        default: Date.now
    },
    notification_status: {
        type: String,
        enum: ['unread', 'read']
    },
    notification_type: {
        type: String,
        enum: ['assigned', 'commented', 'status changed', 'priority changed', 'deleted', 'create']
    },
    notification_from: {
        type: String,
        required: true,
        ref: 'User'
    },
    notification_to: {
        type: String,
        required: true,
        ref: 'User'
    },
    isDeleted: {
        type: Boolean,
        default: false
    }
}, { timestamps: true}
,{ collection: 'notifications'});

module.exports = mongoose.model('Notification', Notification);