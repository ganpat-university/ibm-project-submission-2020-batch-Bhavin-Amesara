const mongoose = require('mongoose');

// Pull Request Schema
// pr_id INT(11) PRIMARY KEY AUTO_INCREMENT
// issue_id INT(11) FOREIGN KEY REFERENCES issue(id)
// project_id INT(11) FOREIGN KEY REFERENCES project(id)
// user_id INT(11) FOREIGN KEY REFERENCES user(id)
// creator_id INT(11) FOREIGN KEY REFERENCES user(id)
// status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending'
// created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
// updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP


const prSchema = new mongoose.Schema({
    issuetracker_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'IssueTracker',
        required: true
    },
    issue_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Issue',
        required: true
    },
    project_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Project',
        required: true
    },
    user_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    creator_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    status: {
        type: String,
        enum: ['pending', 'approved', 'rejected'],
        default: 'pending'
    },
    file: {
        type: [String]
    }
}, { timestamps: true });

module.exports = mongoose.model('PR', prSchema);
