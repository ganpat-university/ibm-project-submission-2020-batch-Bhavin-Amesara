const DashboardCard = ({ title, value, name }) => {
    return (
        <>
            {title} {value}<br />
        </>
    );
};

export default DashboardCard;